<?php
try {
    $pdo = new PDO('mysql:host=localhost; dbname=crudphp', 'root', '');
} catch(PDOException $e) {
    echo "erro $e";
}