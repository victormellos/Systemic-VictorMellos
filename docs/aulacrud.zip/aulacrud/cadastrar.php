<?php
require("conexao.php");

$nome = filter_input(INPUT_POST, "nome");
$sobrenome = filter_input(INPUT_POST, "sobrenome");
$datanasc = filter_input(INPUT_POST, "datanasc");

try {
    $sql = "INSERT INTO cadastro
    (nome, sobrenome, datanasc)
    VALUES
    (:nome, :sobrenome, :datanasc)";
    $statement = $pdo->prepare($sql);
    $statement->bindValue(":nome", $nome);
    $statement->bindValue(":sobrenome", $sobrenome);
    $statement->bindValue(":datanasc", $datanasc);
    $statement->execute();
    header("Location: index.php");

} catch(PDOException $e) {
    echo $e->getMessage();
}
?>