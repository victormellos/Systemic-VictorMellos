<?php
require("conexao.php");

$sql = "SELECT * FROM cadastro";
$statement = $pdo->prepare($sql);
$statement->execute();
$dados = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula php</title>
</head>
<body>

    <form action="cadastrar.php" method="post">
        <input type="text" name="nome" placeholder="digite seu nome">
        <input type="text" name="sobrenome" placeholder="digite seu sobrenome">
        <input type="date" name="datanasc">
        <input type="submit" class="oi" value="Cadastrar">
    </form>
    <hr>
    <table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Sobrenome</th>
        <th>Data Nasc.</th>
        <th>Ações</th>
    </tr>

    <?php foreach($dados as $usuario): ?>
    <tr>
        <td><?= $usuario["id"]; ?></td>
        <td><?= $usuario["nome"]; ?></td>
        <td><?= $usuario["sobrenome"]; ?></td>
        <td><?= $usuario["datanasc"]; ?></td>
        <td>
            <a href="editar.php?id=<?= $usuario["id"]; ?>">
                Editar
            </a>
            <a href="excluir.php?id=<?= $usuario["id"]; ?>">
                Excluir
            </a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>