<?php
require("conexao.php");

$id = filter_input(INPUT_GET, "id");

if($_POST) {
    $nome = filter_input(INPUT_POST, "nome");
    $sobrenome = filter_input(INPUT_POST, "sobrenome");
    $datanasc = filter_input(INPUT_POST, "datanasc");

    $sql = "UPDATE cadastro SET
    nome = :nome,
    sobrenome = :sobrenome,
    datanasc = :datanasc
    WHERE id = :id";

    $statement = $pdo->prepare($sql);
    $statement->bindValue(":nome", $nome);
    $statement->bindValue(":sobrenome", $sobrenome);
    $statement->bindValue(":datanasc", $datanasc);
    $statement->bindValue(":id", $id);

    $statement->execute();

    header("Location: index.php");
}

$sql = "SELECT * FROM cadastro WHERE id = :id";
$statement = $pdo->prepare($sql);
$statement->bindValue(":id", $id);
$statement->execute();
$usuario = $statement->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar</title>
</head>
<body>
<form method="post">
    <input type="text"
    name="nome"
    value="<?= $usuario["nome"]; ?>">
    <input type="text"
    name="sobrenome"
    value="<?= $usuario["sobrenome"]; ?>">
    <input type="date"
    name="datanasc"
    value="<?= $usuario["datanasc"]; ?>">
    <input type="submit" value="Atualizar">
</form>
</body>
</html>)
}